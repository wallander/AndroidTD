package com.chalmers.game.td;

import static org.junit.Assert.*;

import org.junit.Test;

public class GraphicTest {

	@Test
	public final void testGraphic() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testSetBitmap() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testGetBitmap() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testGetSpeed() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testGetCoordinates() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testSetType() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testGetType() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testSetExplosionStep() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testGetExplosionStep() {
		fail("Not yet implemented"); // TODO
	}

}
