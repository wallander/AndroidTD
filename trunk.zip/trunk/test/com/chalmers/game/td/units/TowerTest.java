package com.chalmers.game.td.units;

import static org.junit.Assert.*;

import org.junit.Test;

public class TowerTest {

	@Test
	public final void testTower() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testUpgrade() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testSell() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testUpdate() {
		fail("Not yet implemented"); // TODO
	}

}
