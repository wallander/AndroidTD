package com.chalmers.game.td.units;

import static org.junit.Assert.*;

import org.junit.Test;

public class ProjectileTest {

	@Test
	public final void testProjectile() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testInflictDmg() {
		fail("Not yet implemented"); // TODO
	}

}
