package com.chalmers.game.td;

import static org.junit.Assert.*;

import org.junit.Test;

public class GameActivityTest {

	@Test
	public final void testOnCreateBundle() {
		fail("Not yet implemented"); // TODO
	}

}
