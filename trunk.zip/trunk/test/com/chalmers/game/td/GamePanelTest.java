package com.chalmers.game.td;

import static org.junit.Assert.*;

import org.junit.Test;

public class GamePanelTest {

	@Test
	public final void testGamePanel() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testOnTouchEventMotionEvent() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testUpdatePhysics() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testOnDrawCanvas() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testSurfaceChanged() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testSurfaceCreated() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testSurfaceDestroyed() {
		fail("Not yet implemented"); // TODO
	}

}
