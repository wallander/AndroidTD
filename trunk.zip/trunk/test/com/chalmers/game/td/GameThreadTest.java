package com.chalmers.game.td;

import static org.junit.Assert.*;

import org.junit.Test;

public class GameThreadTest {

	@Test
	public final void testRun() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testGameThread() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testSetRunning() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public final void testIsRunning() {
		fail("Not yet implemented"); // TODO
	}

}
